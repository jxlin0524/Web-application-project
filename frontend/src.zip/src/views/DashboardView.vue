<script setup lang="ts">
import { ref, onMounted } from 'vue';
import { useRouter } from 'vue-router';
// 1. 使用 Heroicons 替换 Lucide 图标
import { 
  PlusIcon, 
  BookOpenIcon, 
  EllipsisVerticalIcon, 
  ClockIcon 
} from '@heroicons/vue/24/outline';
// 2. 引入你的 AppNavbar 组件
import AppNavbar from '../components/AppNavbar.vue';
// 3. 使用真实的 API
import api from '../services/api';

// 定义符合你数据库结构的接口
interface Project {
  project_id: number;
  title: string;
  description: string;
  genre?: string;
  created_at: string;
  // 前端模拟字段
  word_count?: number;
}

const router = useRouter();
const projects = ref<Project[]>([]);
const loading = ref(true);
const showCreateModal = ref(false);
const newProject = ref({ title: '', genre: '', description: '' });

// 获取项目列表
const loadProjects = async () => {
  loading.value = true;
  try {
    const res = await api.get('/projects');
    // 映射数据并添加模拟字数
    projects.value = res.data.data.projects.map((p: Project) => ({
      ...p,
      word_count: Math.floor(Math.random() * 50000) + 1000 // 模拟字数
    }));
  } catch (e) {
    console.error("Failed to load projects", e);
  } finally {
    loading.value = false;
  }
};

// 创建项目
const handleCreate = async () => {
  if (!newProject.value.title) return;
  
  loading.value = true;
  try {
    await api.post('/projects', {
      title: newProject.value.title,
      description: newProject.value.description,
      genre: newProject.value.genre
    });
    
    await loadProjects(); // 重新加载列表
    showCreateModal.value = false;
    newProject.value = { title: '', genre: '', description: '' };
  } catch {
    alert('Failed to create project');
  } finally {
    loading.value = false;
  }
};

const openProject = (id: number) => {
  router.push(`/editor/${id}`);
};

// 格式化日期
const formatDate = (dateString: string) => {
  return new Date(dateString).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });
};

onMounted(loadProjects);
</script>

<template>
  <div class="min-h-screen bg-[#f8fafc] flex flex-col">
    
    <!-- 引入顶部导航栏 -->
    <AppNavbar />

    <div class="flex-1 p-8 overflow-y-auto">
      <div class="max-w-7xl mx-auto">
        
        <!-- Header Section -->
        <div class="flex items-center justify-between mb-8">
          <div>
            <h1 class="text-3xl font-serif font-bold text-slate-800">Your Projects</h1>
            <p class="text-slate-500 mt-1">Manage your novels and short stories.</p>
          </div>
          <button
            @click="showCreateModal = true"
            class="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-lg flex items-center space-x-2 shadow-md transition-all"
          >
            <PlusIcon class="w-5 h-5" />
            <span>New Project</span>
          </button>
        </div>

        <!-- Loading State -->
        <div v-if="loading && projects.length === 0" class="flex justify-center py-20 text-slate-400">
          Loading...
        </div>

        <!-- Grid Layout -->
        <div v-else class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          
          <!-- Project Card -->
          <div
            v-for="project in projects"
            :key="project.project_id"
            @click="openProject(project.project_id)"
            class="group bg-white rounded-xl border border-slate-200 p-6 cursor-pointer hover:shadow-lg hover:border-indigo-200 transition-all duration-300 relative overflow-hidden"
          >
            <!-- Card Action Menu (Top Right) -->
            <div class="absolute top-0 right-0 p-4 opacity-0 group-hover:opacity-100 transition-opacity">
               <EllipsisVerticalIcon class="w-5 h-5 text-slate-400 hover:text-slate-600" />
            </div>
            
            <!-- Icon & Genre Tag -->
            <div class="flex items-start justify-between mb-4">
              <div class="p-3 bg-indigo-50 rounded-lg text-indigo-600">
                <BookOpenIcon class="w-6 h-6" />
              </div>
              <span class="text-xs font-medium px-2 py-1 bg-slate-100 text-slate-600 rounded-full">
                {{ project.genre || 'General' }}
              </span>
            </div>
            
            <!-- Title & Desc -->
            <h3 class="text-xl font-bold text-slate-800 mb-2 font-serif group-hover:text-indigo-700 transition-colors">
              {{ project.title }}
            </h3>
            <p class="text-slate-500 text-sm mb-4 line-clamp-2 h-10">
              {{ project.description || 'No description provided.' }}
            </p>
            
            <!-- Footer Info -->
            <div class="flex items-center justify-between text-xs text-slate-400 border-t border-slate-100 pt-4">
              <div class="flex items-center space-x-1">
                <ClockIcon class="w-3.5 h-3.5" />
                <span>Updated {{ formatDate(project.created_at) }}</span>
              </div>
              <div>
                {{ project.word_count?.toLocaleString() }} words
              </div>
            </div>
          </div>
          
          <!-- Empty State Card (Click to Create) -->
          <div 
            @click="showCreateModal = true"
            class="border-2 border-dashed border-slate-300 rounded-xl p-6 flex flex-col items-center justify-center text-slate-400 cursor-pointer hover:border-indigo-400 hover:bg-indigo-50 hover:text-indigo-500 transition-all min-h-[240px]"
          >
            <PlusIcon class="w-12 h-12 mb-2 opacity-50" />
            <span class="font-medium">Create your first project</span>
          </div>
        </div>
      </div>

      <!-- Create Modal -->
      <div v-if="showCreateModal" class="fixed inset-0 bg-slate-900/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden">
          <div class="p-6 border-b border-slate-100">
            <h3 class="text-xl font-bold text-slate-800">Create New Project</h3>
          </div>
          <form @submit.prevent="handleCreate" class="p-6 space-y-4">
            <div>
              <label class="block text-sm font-medium text-slate-700 mb-1">Title</label>
              <input
                v-model="newProject.title"
                type="text"
                required
                class="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                placeholder="The Lost Kingdom"
                autofocus
              />
            </div>
            <div>
              <label class="block text-sm font-medium text-slate-700 mb-1">Genre</label>
              <select 
                v-model="newProject.genre"
                class="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
              >
                <option value="">Select Genre</option>
                <option value="Fantasy">Fantasy</option>
                <option value="Sci-Fi">Sci-Fi</option>
                <option value="Romance">Romance</option>
                <option value="Mystery">Mystery</option>
                <option value="Horror">Horror</option>
                <option value="Literary">Literary Fiction</option>
              </select>
            </div>
            <div>
              <label class="block text-sm font-medium text-slate-700 mb-1">Description</label>
              <textarea
                v-model="newProject.description"
                class="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none h-24 resize-none transition-all"
                placeholder="A brief summary..."
              ></textarea>
            </div>
            <div class="flex justify-end space-x-3 pt-2">
              <button
                type="button"
                @click="showCreateModal = false"
                class="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                :disabled="!newProject.title"
                class="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors disabled:opacity-50"
              >
                {{ loading ? 'Creating...' : 'Create Project' }}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>