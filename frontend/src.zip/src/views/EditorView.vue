<script setup lang="ts">
import { ref, onMounted, watch } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { 
  ChevronLeftIcon, 
  DocumentTextIcon,  // 对应 FileText
  PlusIcon,
  CheckCircleIcon,   // 对应 Saved 状态图标
  CloudArrowUpIcon,   // 对应 Saving 状态图标
  ArrowPathIcon
} from '@heroicons/vue/24/outline';
import api from '../services/api';
import { debounce } from 'lodash';

// 定义类型
interface Project {
  project_id: number;
  title: string;
}

interface Document {
  document_id: number;
  title: string;
  content: string;
  updated_at: string;
}

const route = useRoute();
const router = useRouter();
const projectId = route.params.id as string;

const project = ref<Project | null>(null);
const documents = ref<Document[]>([]);
const activeDocId = ref<number | null>(null);
const content = ref('');

const saveStatus = ref<'saved' | 'saving' | 'unsaved'>('saved');
const lastSavedTime = ref<Date | null>(null);

// 加载数据
const loadData = async () => {
  try {
    const [projRes, docRes] = await Promise.all([
      api.get(`/projects/${projectId}`),
      api.get(`/projects/${projectId}/documents`)
    ]);
    
    project.value = projRes.data.data.project;
    documents.value = docRes.data.data.documents;
    
    if (documents.value.length > 0) {
      // 默认选中第一个文档
      switchDocument(documents.value[0]!);
    }
  } catch (e) {
    console.error("Failed to load editor data", e);
  }
};

onMounted(loadData);

// 创建新文档
const handleCreateDoc = async () => {
  const title = `Chapter ${documents.value.length + 1}`;
  try {
    const res = await api.post(`/projects/${projectId}/documents`, {
      title,
      content: ''
    });
    const newDoc = res.data.data.document;
    documents.value.push(newDoc);
    switchDocument(newDoc);
  } catch {
    alert("Failed to create chapter");
  }
};

// 切换文档
const switchDocument = (doc: Document) => {
  activeDocId.value = doc.document_id;
  content.value = doc.content || ''; // 确保 content 不是 undefined
  saveStatus.value = 'saved';
  lastSavedTime.value = new Date(doc.updated_at);
};

// 自动保存逻辑 (防抖)
const triggerAutoSave = debounce(async (docId: number, newContent: string) => {
  saveStatus.value = 'saving';
  try {
    await api.put(`/documents/${docId}/autosave`, { content: newContent });
    saveStatus.value = 'saved';
    lastSavedTime.value = new Date();
    
    // 更新本地列表中的数据，防止切换回来时数据丢失
    const doc = documents.value.find(d => d.document_id === docId);
    if (doc) doc.content = newContent;
    
  } catch (e) {
    saveStatus.value = 'unsaved'; // 保存失败标记为未保存
    console.error("Auto-save failed", e);
  }
}, 2000); // 2秒防抖

// 监听内容变化
watch(content, (newVal, oldVal) => {
  if (!activeDocId.value) return;
  // 只有当内容真的改变时才触发
  if (newVal !== oldVal) {
    saveStatus.value = 'unsaved';
    triggerAutoSave(activeDocId.value, newVal);
  }
});

const getActiveTitle = () => {
  return documents.value.find(d => d.document_id === activeDocId.value)?.title || project.value?.title;
};
</script>

<template>
  <div class="flex h-screen bg-white relative overflow-hidden">
    
    <!-- Left Sidebar: Documents -->
    <div class="w-64 border-r border-slate-200 bg-slate-50 flex flex-col shrink-0">
      <div class="p-4 border-b border-slate-200 flex items-center justify-between bg-white">
        <button @click="router.push('/dashboard')" class="text-slate-500 hover:text-slate-800 flex items-center space-x-1 transition-colors">
          <ChevronLeftIcon class="w-4 h-4" />
          <span class="text-sm font-medium">Back</span>
        </button>
        <button @click="handleCreateDoc" class="p-1.5 bg-indigo-100 text-indigo-600 rounded hover:bg-indigo-200 transition-colors">
          <PlusIcon class="w-4 h-4" />
        </button>
      </div>
      <div class="flex-1 overflow-y-auto p-2 space-y-1">
        <button
          v-for="doc in documents"
          :key="doc.document_id"
          @click="switchDocument(doc)"
          :class="[
            'w-full text-left px-3 py-2 rounded-md text-sm font-medium flex items-center space-x-2 transition-colors',
            activeDocId === doc.document_id 
              ? 'bg-white text-indigo-600 shadow-sm border border-slate-100' 
              : 'text-slate-600 hover:bg-slate-200'
          ]"
        >
          <DocumentTextIcon class="w-4 h-4" :class="activeDocId === doc.document_id ? 'opacity-100' : 'opacity-50'" />
          <span class="truncate">{{ doc.title }}</span>
        </button>
      </div>
    </div>

    <!-- Center: Editor -->
    <div class="flex-1 flex flex-col h-full relative min-w-0">
      <!-- Editor Toolbar -->
      <div class="h-14 border-b border-slate-100 flex items-center justify-between px-6 bg-white z-10 shrink-0">
        <h2 class="text-lg font-serif font-bold text-slate-800 truncate max-w-md">
           {{ getActiveTitle() }}
        </h2>
        
        <div class="flex items-center space-x-4">
          <!-- Save Status -->
          <div class="flex items-center space-x-2 text-xs transition-colors duration-500">
            <span v-if="saveStatus === 'saving'" class="flex items-center text-indigo-500">
              <ArrowPathIcon class="w-3 h-3 animate-spin mr-1" /> Saving...
            </span>
            <span v-if="saveStatus === 'saved'" class="flex items-center text-slate-400">
              <CheckCircleIcon class="w-3 h-3 text-green-500 mr-1" /> 
              Saved {{ lastSavedTime?.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) }}
            </span>
            <span v-if="saveStatus === 'unsaved'" class="flex items-center text-amber-500">
              <CloudArrowUpIcon class="w-3 h-3 mr-1" /> Unsaved changes
            </span>
          </div>
        </div>
      </div>

      <!-- Text Area -->
      <div class="flex-1 overflow-y-auto bg-[#fafbfc] relative">
        <div class="max-w-3xl mx-auto py-12 px-8 min-h-full">
          <textarea
            v-model="content"
            class="w-full h-[calc(100vh-200px)] resize-none bg-transparent border-none outline-none text-lg leading-relaxed font-serif text-slate-800 placeholder-slate-300 focus:ring-0"
            placeholder="Start writing your masterpiece..."
            spellcheck="false"
          ></textarea>
        </div>
      </div>
    </div>

  </div>
</template>