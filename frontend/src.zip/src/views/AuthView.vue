<script setup lang="ts">
import { ref } from 'vue';
import { useRouter } from 'vue-router';
// 使用你已经安装的 Heroicons，替换原本的 Lucide 图标
import { 
  EnvelopeIcon, 
  LockClosedIcon, 
  UserIcon, 
  ArrowRightIcon, 
  BookOpenIcon 
} from '@heroicons/vue/24/outline';
// 使用真实的 API 服务，替换原本的 mockBackend
import api from '../services/api';
import { AxiosError } from 'axios';

const router = useRouter();
const isLogin = ref(true);
const loading = ref(false);
const error = ref('');
// 这里保留你原来的表单结构
const formData = ref({ email: '', password: '', username: '' });

const handleSubmit = async () => {
  loading.value = true;
  error.value = '';
  
  try {
    if (isLogin.value) {
      // 真实的登录接口
      const res = await api.post('/users/login', {
        // 注意：后端 login 接口接收的是 username 字段，但我们前端设计是用 email 登录
        // 这里需要确认后端 authController 是否支持用 email 查用户
        // 如果后端支持 (user = findByUsername || findByEmail)，这里传 email 给 username 字段即可
        username: formData.value.email, 
        password: formData.value.password
      });
      
      localStorage.setItem('token', res.data.data.token);
      localStorage.setItem('user', JSON.stringify(res.data.data.user));
      router.push('/dashboard');
    } else {
      // 真实的注册接口
      await api.post('/users/register', {
        username: formData.value.username,
        email: formData.value.email,
        password: formData.value.password
      });
      
      // 注册成功后自动切换到登录，或者直接登录
      isLogin.value = true;
      alert('Registration successful! Please sign in.');
    }
  } catch (err) {
    const axiosError = err as AxiosError<{ message: string }>;
    error.value = axiosError.response?.data?.message || "Authentication failed. Please check your credentials.";
  } finally {
    loading.value = false;
  }
};
</script>

<template>
  <div class="min-h-screen flex items-center justify-center bg-[#f8fafc] p-4">
    <div class="max-w-4xl w-full bg-white rounded-2xl shadow-2xl overflow-hidden flex flex-col md:flex-row h-[600px]">
      
      <!-- Left: Branding (深色品牌区) -->
      <div class="md:w-1/2 bg-slate-900 p-12 text-white flex flex-col justify-between relative overflow-hidden">
        <!-- 网格背景装饰 -->
        <div class="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
          <svg width="100%" height="100%">
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" strokeWidth="1" />
            </pattern>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>
        </div>

        <div class="z-10">
          <div class="flex items-center space-x-3 mb-6">
            <div class="p-2 bg-indigo-600 rounded-lg">
              <BookOpenIcon class="h-6 w-6 text-white" />
            </div>
            <span class="text-2xl font-bold font-serif">ProsePal</span>
          </div>
          <h1 class="text-4xl font-serif font-bold leading-tight mb-4">
            Write your next<br/>masterpiece.
          </h1>
          <p class="text-slate-400 text-lg">
            The intelligent assistant for web novel authors. Plan, write, and refine with AI-powered tools.
          </p>
        </div>

        <div class="z-10 text-sm text-slate-500">
          <span>Powered by Gemini AI</span>
        </div>
      </div>

      <!-- Right: Form (表单区) -->
      <div class="md:w-1/2 p-12 flex flex-col justify-center">
        <h2 class="text-3xl font-bold text-slate-800 mb-2">
          {{ isLogin ? 'Welcome back' : 'Create an account' }}
        </h2>
        <p class="text-slate-500 mb-8">
          {{ isLogin ? 'Enter your details to access your library.' : 'Start your writing journey today.' }}
        </p>

        <form @submit.prevent="handleSubmit" class="space-y-4">
          <!-- Username (Only for Register) -->
          <div v-if="!isLogin">
            <label class="block text-sm font-medium text-slate-700 mb-1">Username</label>
            <div class="relative">
              <UserIcon class="absolute left-3 top-3 text-slate-400 h-5 w-5" />
              <input
                v-model="formData.username"
                type="text"
                :required="!isLogin"
                class="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none transition-all"
                placeholder="Pen Name"
              />
            </div>
          </div>

          <!-- Email -->
          <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">Email</label>
            <div class="relative">
              <EnvelopeIcon class="absolute left-3 top-3 text-slate-400 h-5 w-5" />
              <input
                v-model="formData.email"
                type="email"
                required
                class="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none transition-all"
                placeholder="author@example.com"
              />
            </div>
          </div>

          <!-- Password -->
          <div>
            <label class="block text-sm font-medium text-slate-700 mb-1">Password</label>
            <div class="relative">
              <LockClosedIcon class="absolute left-3 top-3 text-slate-400 h-5 w-5" />
              <input
                v-model="formData.password"
                type="password"
                required
                class="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none transition-all"
                placeholder="••••••••"
              />
            </div>
          </div>

          <!-- Error Message -->
          <p v-if="error" class="text-red-500 text-sm bg-red-50 p-2 rounded">{{ error }}</p>

          <!-- Submit Button -->
          <button
            type="submit"
            :disabled="loading"
            class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-3 rounded-lg flex items-center justify-center space-x-2 transition-all shadow-md disabled:opacity-70"
          >
            <span>{{ loading ? 'Processing...' : (isLogin ? 'Sign In' : 'Register') }}</span>
            <ArrowRightIcon v-if="!loading" class="h-5 w-5" />
          </button>
        </form>

        <!-- Toggle Login/Register -->
        <div class="mt-8 text-center text-sm text-slate-500">
          {{ isLogin ? "Don't have an account? " : "Already have an account? " }}
          <button @click="isLogin = !isLogin; error = ''" class="text-indigo-600 font-medium hover:underline">
            {{ isLogin ? 'Sign up' : 'Log in' }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>