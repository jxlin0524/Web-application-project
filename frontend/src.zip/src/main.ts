import { createApp } from 'vue'
import { createPinia } from 'pinia'

// 1. 引入全局样式 (包含 Tailwind)
import './style.css'

// 2. 引入根组件
import App from './App.vue'

// 3. 引入路由
import router from './router'

const app = createApp(App)

app.use(createPinia())
app.use(router)

app.mount('#app')